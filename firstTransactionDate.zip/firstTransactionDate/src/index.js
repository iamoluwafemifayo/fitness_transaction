import { createApp } from "@deroll/app";
import { getAddress, hexToString, stringToHex } from "viem";

const app = createApp({ url: process.env.ROLLUP_HTTP_SERVER_URL || "http://127.0.0.1:5004" });

let firstTransactionDates = {};

app.addAdvanceHandler(async ({ metadata }) => {
    const sender = getAddress(metadata.msg_sender);
    console.log("Sender address:", sender);

    if (!firstTransactionDates[sender]) {
        firstTransactionDates[sender] = new Date().toISOString();
        console.log(`First transaction date for ${sender}:`, firstTransactionDates[sender]);
    }

    return "accept";
});

app.addInspectHandler(async ({ payload }) => {
    const url = hexToString(payload).split("/"); // e.g., "rollup/firstTransactionDate/0x1234..."
    console.log("Inspect call:", url);
    
    if (url[1] === "firstTransactionDate") {
        const address = getAddress(url[2]);
        const date = firstTransactionDates[address] || "No transactions found";
        await app.createReport({ payload: stringToHex(date) });
    } else {
        console.log("Invalid inspect call");
        await app.createReport({ payload: stringToHex("Invalid inspect call") });
    }
});

app.start().catch((e) => {
    console.error(e);
    process.exit(1);
});
