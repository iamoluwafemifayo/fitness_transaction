import { createApp } from "@deroll/app";
import { getAddress, hexToString, stringToHex } from "viem";

const app = createApp({ url: process.env.ROLLUP_HTTP_SERVER_URL || "http://127.0.0.1:5004" });

let users = {};

app.addAdvanceHandler(async ({ metadata, payload }) => {
    const sender = getAddress(metadata.msg_sender);
    const payloadString = hexToString(payload);
    console.log("Sender:", sender, "Payload:", payloadString);

    try {
        const jsonPayload = JSON.parse(payloadString);

        if (jsonPayload.method === "log_activity") {
            const activity = jsonPayload.activity;
            if (!users[sender]) users[sender] = { activities: [], rewards: BigInt(0) };
            users[sender].activities.push(activity);
            console.log("Activity logged:", activity);

            // Check if user met reward criteria (e.g., total steps)
            if (activity.steps >= 10000) {
                users[sender].rewards += BigInt(10); // Reward 10 tokens
                console.log("Reward granted:", 10);
            }

        }

        return "accept";
    } catch (e) {
        console.error(e);
        app.createReport({ payload: stringToHex(String(e)) });
        return "reject";
    }
});

app.addInspectHandler(async ({ payload }) => {
    const address = getAddress(hexToString(payload).split("/")[1]);
    const user = users[address] || {};
    await app.createReport({ payload: stringToHex(JSON.stringify(user)) });
});

app.start().catch((e) => {
    console.error(e);
    process.exit(1);
});
